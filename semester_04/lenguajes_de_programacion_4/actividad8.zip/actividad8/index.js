$( function() {
  $( "#datepicker" ).datepicker();
} )

$( function() {
  $( "#datepicker-2" ).datepicker();
} )

$(function() {
  $(".controlgroup" )
    .controlgroup()
  $(".controlgroup-vertical" )
    .controlgroup({
      "direction": "vertical"
    })
  } 
)